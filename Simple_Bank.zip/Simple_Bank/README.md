# IT202-001
## Ritika Suresh
### CS sophomore

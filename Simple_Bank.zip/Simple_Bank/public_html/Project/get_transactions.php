<?php
require(__DIR__ . "/../../partials/nav.php");
?>
<?php
//get variables
$from = $_GET['from'];
$to = date('Y-m-d', strtotime($_GET['to'] .' +1 day')); //to make inclusive
$type = $_GET['type'];
$account_id = $_GET['account_id'];

//fill $sql if empty or not
if(!empty($from) && !empty($to)){
    $date_range = " AND created BETWEEN '".$from."' AND '".$to."' ";
}else{
    $date_range = "";
}

if($type != ''){
    $type = " AND transaction_type = '$type' ";
}

$columns = ' src, dest, balance_change, transaction_type, memo, cast(created as date) created, expected_total ';
$table = ' Transactions ';
$where = " WHERE (src='$account_id' OR dest='$account_id') ".$date_range.$type;
$sql = "SELECT ".$columns." FROM ".$table." ".$where;
$db = getDB();
$stmt = $db->prepare($sql);
$stmt->execute();
$transactions = array();
while ($transaction = $stmt->fetch(PDO::FETCH_OBJ))
{
    $transactions[] = $transaction;
}
echo json_encode($transactions);
?>
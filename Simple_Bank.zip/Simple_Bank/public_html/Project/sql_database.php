<?php
require(__DIR__ . "/../../partials/nav.php");
?>
<h1>SQL DATABASE</h1>
<?php
    $db = getDB();
    $stmt2 = $db->prepare("SELECT email, username, first, last, id from Users");
    $stmt2->execute();
    $users = $stmt2->fetchAll(PDO::FETCH_OBJ);
    foreach ($users as $user)
    {
        echo '<pre class="user">'; print_r($user); echo '</pre>';
        $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type from Accounts where user_id=$user->id");
        $stmt->execute();
        $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
        foreach ($accounts as $account)
        {
            echo '<pre class="account">'; print_r($account); echo '</pre>';
            $stmt3 = $db->prepare("SELECT id, src, dest, balance_change, transaction_type, memo, created, expected_total from Transactions where src=$account->id or dest=$account->id");
            $stmt3->execute();
            $transactions = $stmt3->fetchAll(PDO::FETCH_OBJ);
            foreach ($transactions as $transaction)
            {
                echo '<pre class="transaction">'; print_r($transaction); echo '</pre>';
            }
        }
    }
    
    
?>
<?php
require(__DIR__ . "/../../partials/footer.php");
?>
<?php
require(__DIR__ . "/../../partials/nav.php");
reset_session();
?>
<?php
$first = se($_POST, "first", "", false);
$last = se($_POST, "last", "", false);
$email = se($_POST, "email", "", false);
$username = se($_POST, "username", "", false);
$password = se($_POST, "password", "", false);
$confirm = se($_POST, "confirm", "", false);
?>

<div class="container-fluid">
    <h1>Register</h1>
    <form onsubmit="return validate(this)" method="POST">
        <div class="mb-3">
            <label class="form-label" for="username">First name</label>
            <input class="form-control" type="text" name="first" required value="<?php se($first); ?>" />
        </div>
        <div class="mb-3">
            <label class="form-label" for="username">Last name</label>
            <input class="form-control" type="text" name="last" required value="<?php se($last); ?>" />
        </div>
        <div class="mb-3">
            <label class="form-label" for="email">Email</label>
            <input class="form-control" type="email" id="email" name="email" required value="<?php se($email); ?>" />
        </div>
        <div class="mb-3">
            <label class="form-label" for="username">Username</label>
            <input class="form-control" type="text" name="username" required maxlength="30" required value="<?php se($username); ?>" />
        </div>
        <div class="mb-3">
            <label class="form-label" for="pw">Password</label>
            <input class="form-control" type="password" id="pw" name="password" required minlength="8" />
        </div>
        <div class="mb-3">
            <label class="form-label" for="confirm">Confirm</label>
            <input class="form-control" type="password" name="confirm" required minlength="8" />
        </div>
        <input type="submit" class="mt-3 btn btn-primary" value="Register" />
    </form>
</div>
<script>
    function validate(form) {
        //TODO 1: implement JavaScript validation
        //ensure it returns false for an error and true for success

        return true;
    }
</script>
<?php
//TODO 2: add PHP Code
if (isset($_POST["first"]) && isset($_POST["last"]) && isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["confirm"])) {
    //TODO 3
    $hasError = false;
    if (empty($first)) {
        flash("First name must not be empty", "danger");
        $hasError = true;
    }
    if (!preg_match('/^[a-zA-Z]{1,}$/i', $first)) {
        flash("First name must only be alpha", "danger");
        $hasError = true;
    }
    if (empty($last)) {
        flash("Last name must not be empty", "danger");
        $hasError = true;
    }
    if (!preg_match('/^[a-zA-Z]{1,}$/i', $last)) {
        flash("Last name must only be alpha", "danger");
        $hasError = true;
    }
    if (empty($email)) {
        flash("Email must not be empty", "danger");
        $hasError = true;
    }
    //sanitize
    $email = sanitize_email($email);
    //validate
    if (!is_valid_email($email)) {
        flash("Invalid email address", "danger");
        $hasError = true;
    }
    if (!preg_match('/^[a-z0-9_-]{3,16}$/i', $username)) {
        flash("Username must only be alphanumeric and can only contain - or _", "danger");
        $hasError = true;
    }
    if (empty($password)) {
        flash("Password must not be empty", "danger");
        $hasError = true;
    }
    if (empty($confirm)) {
        flash("Confirm password must not be empty", "danger");
        $hasError = true;
    }
    if (strlen($password) < 8) {
        flash("Password too short", "danger");
        $hasError = true;
    }
    if (strlen($password) > 0 && $password !== $confirm) {
        flash("Passwords must match", "danger");
        $hasError = true;
    }
    if (!$hasError) {
        //TODO 4
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO Users (email, password, username, first, last) VALUES(:email, :password, :username, :first, :last)");
        try {
            $stmt->execute([":email" => $email, ":password" => $hash, ":username" => $username, ":first" => $first, ":last" => $last]);
            flash("Successfully registered!");
        } catch (Exception $e) {
            users_check_duplicate($e->errorInfo);
        }
    }
}
?>
<?php
require(__DIR__ . "/../../partials/footer.php");
?>
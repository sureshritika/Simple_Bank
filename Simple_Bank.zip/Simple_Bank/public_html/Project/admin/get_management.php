<?php
require(__DIR__ . "/../../../partials/nav.php");
?>
<?php
//get variables
$first = $_GET['first'];
$last = $_GET['last'];
$account_number = $_GET['account_number'];
$action = $_GET['action'];

$db = getDB();

if ($action == "populate")
{
    $sql = "SELECT Users.first, Users.last, Users.is_active, Accounts.account_number, Accounts.frozen FROM Users INNER JOIN Accounts ON Users.id=Accounts.user_id WHERE Accounts.account_type != 'world' AND account_type != 'system'";
    if (!empty($first))
        $first_filter = " AND Users.first = '$first'";
    else
        $first_filter = "";
    if (!empty($last))
        $last_filter = " AND Users.last = '$last'";
    else
        $last_filter = "";
    if (!empty($account_number))
        $account_filter = " AND Accounts.account_number LIKE '%$account_number%'";
    else
        $account_filter = "";
    $sql = $sql.$first_filter.$last_filter.$account_filter;

    $stmt = $db->prepare($sql);
    $stmt->execute();
    $users_accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
    echo json_encode($users_accounts);
}
if ($action == "frozen")
{
    $stmt = $db->prepare("SELECT id, account_number, user_id, frozen from Accounts where account_number='$account_number'");
    $stmt->execute();
    $account = $stmt->fetch(PDO::FETCH_OBJ);
    $frozen = $account->frozen;
    $set = "";
    if ($frozen == "0")
        $set = 1;
    else
        $set = 0;
    $stmt = $db->prepare("UPDATE Accounts SET frozen=$set WHERE account_number='$account_number'");
    $stmt->execute();
    echo json_encode($account);
}
if ($action == "user_populate")
{
    $stmt = $db->prepare("SELECT email, username, first, last, is_active from Users where username!='system'");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_OBJ);
    echo json_encode($users);
}
if ($action == "active")
{
    $username = $account_number;
    $stmt = $db->prepare("SELECT email, username, first, last, is_active from Users where username='$username'");
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_OBJ);
    $active = $user->is_active;
    $set = "";
    if ($active == "0")
        $set = 1;
    else
        $set = 0;
    echo '<pre>'; print_r($user); echo '</pre>';
    $stmt = $db->prepare("UPDATE Users SET is_active=$set WHERE username='$username'");
    $stmt->execute();
    echo json_encode($user);
}
?>
<?php
require(__DIR__ . "/../../../partials/nav.php");
if (!has_role("Admin")) {
    flash("You don't have permission to view this page", "warning");
    die(header("Location: $BASE_PATH" . "dashboard.php"));
}
?>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/dataTables.bootstrap4.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/dataTables.bootstrap4.min.js"></script>
  </head>
<h1>Account Management</h1>
<?php
    $first = se($_GET, "first", "", false);
    $last = se($_GET, "last", "", false);
    $account_number = se($_GET, "account_number", "", false);
    $user_id = get_user_id();
    $db = getDB();
    $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, cast(created as date) created from Accounts where account_type != 'world' AND account_type != 'system'");
    $stmt->execute();
    $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
    //echo '<pre>'; print_r($accounts); echo '</pre>';

?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
            <div class="row well">
              <div class="col-sm-3 input" style="display: inline">
                <label class="control-label">Account Number</label>
                <input class="form-control" type="text" name="account_number" id="account_number" style="height: 40px;"/>
              </div>
              <div class="col-sm-3 input" style="display: inline">
                <label class="control-label">First</label>
                <input class="form-control" type="text" name="first" id="first" style="height: 40px;"/>
              </div>
              <div class="col-sm-3 input" style="display: inline">
                <label class="control-label">Last</label>
                <input class="form-control" type="text" name="last" id="last" style="height: 40px;"/>
              </div>
              <div class="col-sm-2" style="display: inline">
                <button class="btn btn-success btn-block" type="submit" name="filter" id="filter" style="margin-top: 30px">
                  <i class="fa fa-filter"></i> Filter
                </button>
              </div>
              <div class="col-sm-12 text-danger" id="error_log"></div>
            </div>
                <div class="table-responsive">
                    <table id="accounts" style="width:100%;" class="table table-striped table-bordered table-hover display">
                        <thead>
                          <tr>
                            <td>First</td>
                            <td>Last</td>
                            <td>Account number</td>
                            <td style="width:0%">Freeze?</td>
                          </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    load_data("","",""); // first load
    //fill datatable
    function load_data(first, last, account_number)
    {
      //call to get_transactions.php to create json to fill datatable
      var http2 = new XMLHttpRequest();
      http2.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            var str = this.responseText.substring(this.responseText.indexOf("["));
            console.log(str);            
            var data = JSON.parse(str);
            $('#accounts').DataTable
            ({
              "searching" : false,
              "lengthChange" : false,
              "pageLength" : 10,
              "ordering" : false,
              "responsive": true,
              "data" : data,
              "columns" :
              [
                { "data" : "first" },
                { "data" : "last" },
                { "data" : "account_number" },
                {
                  "data": null,      
                  "defaultContent": "",
                  "render": function (data)
                  {
                    if (data.frozen == 1)
                      return '<button class="btn"><i class="fa fa-unlock"></i></button';
                    else
                      return '<button class="btn"><i class="fa fa-lock"></i></button';
                  },
                  className: 'row-freeze dt-center',
                }
              ],
              columnDefs:
              [{
                "defaultContent" : "-",
                "targets" : "_all"
              }]
            });
          }
      };
      //send variables
      http2.open("GET", "get_management.php?first="+first+"&last="+last+"&account_number="+account_number+"&action=populate", true);
      http2.send();
    }
    //call load_data to reload datatable with new filter options
    $("#filter").click(function(){
      var first = $("#first").val();
      var last = $("#last").val();
      var account_number = $("#account_number").val();

      if(first == '' && last == '')
      {
        $('#accounts').DataTable().destroy();
        load_data("", "", account_number); // filter immortalize only
      }else
      {
        $("#error_log").html(""); 
        $('#accounts').DataTable().destroy();
        load_data(first, last, account_number);
      }
    });
    //row click for transaction history
    $('#accounts').on('click', 'tr td:not(:last-child)', function () {
        var row = $('#accounts').DataTable().row(this);
        var account = row.data();
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            //tr.removeClass('shown');
        }
        else {
            // Open this row
            row.child(format(row.data())).show();
            //tr.addClass('shown');
        }
    });
    //get transaction history info
    function format (d) {
      var account_number = d.account_number;
      <?php
        $accounts = json_encode($accounts);
        $stmt = $db->prepare("SELECT src, dest, balance_change, transaction_type, memo, cast(created as date) created, expected_total FROM Transactions");
        $stmt->execute();
        $transactions = json_encode($stmt->fetchAll(PDO::FETCH_OBJ));
      ?>
      var accounts = <?php echo $accounts; ?>;
      var transactions = <?php echo $transactions; ?>;
      var account_id;
      for (let a = 0 ; a < accounts.length ; a ++)
      {
        if (accounts[a].account_number == account_number)
        {
          account_id = accounts[a].id;
        }
      }
      console.log(account_id);
      for (let a = transactions.length-1 ; a >= 0 ; a --)
      {
        if (transactions[a].src != account_id && transactions[a].dest != account_id)
          transactions.splice(a, 1);
      }
      console.log(transactions);

      var table = document.createElement("table");
      let innerT = "";
      innerT += "<tr style='color:black' class='firstRow'><th>Src</th><th>Dest</th><th>Balance change</th><th>Transaction type</th><th>Memo</th><th>Created</th><th>Expected total</th></tr>";
      for (var a = 0 ; a < transactions.length ; a ++)
      {
        innerT += "<tr>";
        innerT += "<td>" + transactions[a].src + "</td>";
        innerT += "<td>" + transactions[a].dest + "</td>";
        innerT += "<td>" + transactions[a].balance_change + "</td>";
        innerT += "<td>" + transactions[a].transaction_type + "</td>";
        innerT += "<td>" + transactions[a].memo + "</td>";
        innerT += "<td>" + transactions[a].created + "</td>";
        innerT += "<td>" + transactions[a].expected_total + "</td>";
        innerT += "</tr>";
      }
      table.innerHTML = innerT;
      return table;
      
    }
    //freeze account
    $('#accounts').on( 'click', 'tr td.row-freeze', function (e) {
      var row = $('#accounts').DataTable().row(this);
      var row_index = $(this).closest('tr').index();
      var first = row.data().first;
      var last = row.data().last;
      var account_number = row.data().account_number;
      var data = $('#accounts').DataTable().row( $(this).parents('tr') ).data();
      console.log(data);
      $.ajax({url: "get_management.php?first=&last=&account_number="+account_number+"&action=frozen", success: function(result){}});
      $('#accounts').DataTable().destroy();
      load_data("","","");
    });
</script>
<?php
//note we need to go up 1 more directory
require_once(__DIR__ . "/../../../partials/flash.php");
?>
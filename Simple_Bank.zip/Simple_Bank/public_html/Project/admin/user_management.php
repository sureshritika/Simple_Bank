<?php
require(__DIR__ . "/../../../partials/nav.php");
if (!has_role("Admin")) {
    flash("You don't have permission to view this page", "warning");
    die(header("Location: $BASE_PATH" . "dashboard.php"));
}
?>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/dataTables.bootstrap4.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/dataTables.bootstrap4.min.js"></script>
  </head>
<h1>User Management</h1>
<?php
    $first = se($_GET, "first", "", false);
    $last = se($_GET, "last", "", false);
    $account_number = se($_GET, "account_number", "", false);
    $user_id = get_user_id();
    $db = getDB();
    $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, cast(created as date) created from Accounts where account_type != 'world' AND account_type != 'system'");
    $stmt->execute();
    $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
    //echo '<pre>'; print_r($accounts); echo '</pre>';

?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
                <div class="table-responsive">
                    <table id="accounts" style="width:100%;" class="table table-striped table-bordered table-hover display">
                        <thead>
                          <tr>
                            <td>Email</td>
                            <td>Username</td>
                            <td>First</td>
                            <td>Last</td>
                            <td style="width:0%">Active?</td>
                          </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    load_data("","",""); // first load
    //fill datatable
    function load_data(first, last, account_number)
    {
      //call to get_transactions.php to create json to fill datatable
      var http2 = new XMLHttpRequest();
      http2.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            
            var str = this.responseText.substring(this.responseText.indexOf("["));
            console.log(str);            
            var data = JSON.parse(str);
            console.log(data);
            $('#accounts').DataTable
            ({
              "searching" : false,
              "lengthChange" : false,
              "pageLength" : 10,
              "ordering" : false,
              "responsive": true,
              "data" : data,
              "columns" :
              [
                { "data" : "email" },
                { "data" : "username" },
                { "data" : "first" },
                { "data" : "last" },
                {
                  "data": null,      
                  "defaultContent": "",
                  "render": function (data)
                  {
                    if (data.is_active == 1)
                      return '<button class="btn"><i class="fa fa-ban"></i></button';
                    else
                      return '<button class="btn"><i class="fa fa-circle-o"></i></button';
                  },
                  className: 'row-active dt-center',
                }
              ],
              columnDefs:
              [{
                "defaultContent" : "-",
                "targets" : "_all"
              }]
            });
          }
      };
      //send variables
      http2.open("GET", "get_management.php?first="+first+"&last="+last+"&account_number="+account_number+"&action=user_populate", true);
      http2.send();
    }
    //(de)active account
    $('#accounts').on( 'click', 'tr td.row-active', function (e) {
      var row = $('#accounts').DataTable().row(this);
      var row_index = $(this).closest('tr').index();
      var first = row.data().first;
      var last = row.data().last;
      var username = row.data().username;
      $.ajax({url: "get_management.php?first=&last=&account_number="+username+"&action=active", success: function(result){}});
      $('#accounts').DataTable().destroy();
      load_data("","","");
    });
</script>
<?php
//note we need to go up 1 more directory
require_once(__DIR__ . "/../../../partials/flash.php");
?>
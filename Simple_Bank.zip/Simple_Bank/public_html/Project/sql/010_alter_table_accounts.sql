ALTER TABLE Accounts 
DROP CHECK Accounts_chk_1;
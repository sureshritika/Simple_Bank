ALTER TABLE Users 
ADD COLUMN first varchar(100) not null default '',
ADD COLUMN last varchar(100) not null default '';
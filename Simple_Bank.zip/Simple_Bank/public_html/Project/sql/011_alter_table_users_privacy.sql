ALTER TABLE Users ADD COLUMN privacy varchar(10) not null default 'public';
ALTER TABLE Users ADD COLUMN visibility BOOLEAN DEFAULT FALSE;
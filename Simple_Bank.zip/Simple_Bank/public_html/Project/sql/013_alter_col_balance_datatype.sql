ALTER TABLE Accounts MODIFY COLUMN balance DOUBLE(10,2) DEFAULT '0.00';
ALTER TABLE Transactions MODIFY COLUMN balance_change double(10,2);
ALTER TABLE Transactions MODIFY COLUMN expected_total double(10,2);
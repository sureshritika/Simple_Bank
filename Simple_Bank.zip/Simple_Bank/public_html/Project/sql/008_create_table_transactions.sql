CREATE TABLE IF NOT EXISTS Transactions(
    id int AUTO_INCREMENT PRIMARY KEY ,
    src int COMMENT 'accounts.id',
    dest int COMMENT 'accounts.id',
    balance_change int,
    transaction_type varchar(100) DEFAULT '' COMMENT 'i.e., deposit, withdraw, transfer, ext-transfer',
    memo varchar(240) default null COMMENT  'user-defined notes',
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expected_total int,
    FOREIGN KEY (src) REFERENCES Accounts(id),
    FOREIGN KEY(dest) REFERENCES Accounts(id),
    constraint ZeroTransferNotAllowed CHECK(balance_change != 0)
)
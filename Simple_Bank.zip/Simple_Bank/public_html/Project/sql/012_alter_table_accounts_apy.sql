ALTER TABLE Accounts 
ADD COLUMN apy double(10,10) not null default '0';
<?php
require(__DIR__ . "/../../partials/nav.php");
?>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/dataTables.bootstrap4.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
</head>
<h1>Transaction History</h1>
<?php
  if (is_logged_in(true)) {
    //get row index of account clicked from accounts page
    $user_id = get_user_id();
    $row_index = $_GET['row_index'];
    //flash($row_index);
    $db = getDB();
    //get account info from row clicked
    $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, cast(created as date) created from Accounts where account_type != 'world' AND account_type != 'system' AND user_id=$user_id AND active = TRUE");
    //$stmt->execute();
    //echo '<pre>'; print_r($stmt->fetchAll(PDO::FETCH_OBJ)); echo '</pre>';
    $stmt->execute();
    $account = $stmt->fetchAll(PDO::FETCH_OBJ)[$row_index];
    //echo '<pre>'; print_r($account); echo '</pre>';
    $account_id = $account->id;
    //print account info
    echo "Account number: " . $account->account_number . "<br>";
    echo "Account type: " . $account->account_type . "<br>";
    echo "Balance: $" . $account->balance . "<br>";
    echo "Date created: " . $account->created . "<br>";
  }
?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card p-2">
              <!--<div>
              <input class="form-control" type="text" id="textbox"/>
              </div>-->
              <div class="row well">
                <div class="col-sm-4">
                  <label class="control-label">Type</label>
                  <select class="form-control" name="type" id="type" style="height: 40px;">
                    <option value="">- Please select -</option>
                    <option value="deposit">Deposit</option>
                    <option value="withdraw">Withdraw</option>
                    <option value="transfer">Transfer</option>
                  </select>
                </div>
                <div class="col-sm-3 input-daterange">
                  <label class="control-label">From</label>
                  <input class="form-control datepicker" type="text" name="from" id="from" placeholder="yyyy-mm-dd" style="height: 40px;"/>
                </div>
                <div class="col-sm-3 input-daterange">
                  <label class="control-label">To</label>
                  <input class="form-control datepicker" type="text" name="to" id="to" placeholder="yyyy-mm-dd" style="height: 40px;"/>
                </div>
                <div class="col-sm-2">
                  <button class="btn btn-success btn-block" type="submit" name="filter" id="filter" style="margin-top: 30px">
                    <i class="fa fa-filter"></i> Filter
                  </button>
                </div>
                <div class="col-sm-12 text-danger" id="error_log"></div>
              </div>
                <div class="table-responsive">
                    <table id="transactions" style="width:100%;" class="table table-striped table-bordered">
                        <thead>
                          <tr>
                              <td>Src</td>
                              <td>Dest</td>
                              <td>Balance change</td>
                              <td>Transaction type</td>
                              <td>Memo</td>
                              <td>Created</td>
                              <td>Expected total</td>
                          </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    load_data("","",""); // first load
    //fill datatable
    function load_data(from, to, type)
    {
      //call to get_transactions.php to create json to fill datatable
      var http2 = new XMLHttpRequest();
      http2.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            var str = this.responseText.substring(this.responseText.indexOf("["));
            //document.getElementById('textbox').value = str;
            console.log(str);            
            var data = JSON.parse(str);
            data.reverse();
            $('#transactions').DataTable
            ({
              "searching" : false,
              "lengthChange" : false,
              "pageLength" : 10,
              "ordering" : false,
              "data" : data,
              "columns" :
              [
                { "data" : "src" },
                { "data" : "dest" },
                { "data" : "balance_change" },
                { "data" : "transaction_type" },
                { "data" : "memo" },
                { "data" : "created" },
                { "data" : "expected_total" }
              ],
              columnDefs:
              [{
                "defaultContent" : "-",
                "targets" : "_all"
              }]
            });  
          }
      };
      //send variables
      http2.open("GET", "get_transactions.php?from="+from+"&to="+to+"&type="+type+"&account_id=<?php echo $account_id;?>", true);
      http2.send();
    }
    //call load_data to reload datatable with new filter options
    $("#filter").click(function(){
      var from = $("#from").val();
      var to = $("#to").val();
      var type = $("#type").val();

      if(from == '' && to == ''){
        $('#transactions').DataTable().destroy();
        load_data("", "", type); // filter immortalize only
      }else{
        var date1 = new Date(from);
        var date2 = new Date(to);
        var diffTime = Math.abs(date2 - date1);
        var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 

        if(from == '' || to == ''){
            $("#error_log").html("Warning: You must select both (start and end) date.</span>");
        }else{
          if(date1 > date2){
              $("#error_log").html("Warning: End date should be greater then start date.");
          }else{
            $("#error_log").html(""); 
            $('#transactions').DataTable().destroy();
            load_data(from, to, type);
          }
        }
      }
    });
    //datepicker properties
    $('.input-daterange').datepicker({
      todayBtn:'linked',
      format: "yyyy-mm-dd",
      endDate: "0d",
      clearBtn: true,
      autoclose: true
    });
</script>
<?php
require(__DIR__ . "/../../partials/footer.php");
?>
<?php
require(__DIR__ . "/../../partials/nav.php");
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<h1>Withdraw</h1>
<script>
function validate(form) {
    return true;
}
</script>
<?php
$selected_account = se($_POST, "select_account", "", false);
$amount = se($_POST, "amount", "", false);
$memo = se($_POST, "memo", "", false);
/*
echo "selected_account: $selected_account<br>";
echo "amount: $amount<br>";
echo "memo: $memo<br>";
*/
if (is_logged_in(true)) {
    if (has_account(true))
    {
        if (isset($_SESSION["success"]))
        {
            flash("successful withdraw", "success");
            unset($_SESSION["success"]);
        }
        $id = get_user_id();
        $db = getDB();
        //get accounts info
        $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created, apy, active, frozen from Accounts where user_id = :id  AND active = TRUE and account_type != 'loan'");
        try
        {
            $r = $stmt->execute([":id" => $id]);
            if ($r)
                $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        catch (Exception $e)
        {
            flash("<pre>" . var_export($e, true) . "</pre>");
        }
        //deposit button clicked
        if(isset($_POST["withdraw"]))
        {
            //get world account info
            $stmt3 = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created from Accounts where account_type='world'");
            $stmt3->execute();
            $world = $stmt3->fetch(PDO::FETCH_OBJ);
            //get row index of selected dropdown
            $row_index = 0;
            for ($a = 0 ; $a < sizeof($accounts) ; $a ++)
            {
                if ($accounts[$a]->account_number == $selected_account)
                    $row_index = $a;
            }
            //get account information
            $account_id = $accounts[$row_index]->id;
            $balance = $accounts[$row_index]->balance;
            //check if withdraw amount is less than account balance
            $hasError = false;
            if ($amount <= 0)
            {
                flash("Withdraw value takes only positive numberic value", "danger");
                $hasError = true;
            }
            if ($amount > $balance)
            {
                flash("Insufficient funds", "danger");
                $hasError = true;
            }
            if (!$hasError)
            {
                //insert withdraw info into transactions from user to world 1
                $stmt2 = $db->prepare("INSERT INTO Transactions (src, dest, balance_change, transaction_type, memo, expected_total) VALUES (:src, :dest, :balance_change, :transaction_type, :memo, :expected_total)");
                try
                { 
                    $world_id = $world->id;
                    $world_balance = $world->balance;
                    //insert withdraw info into transactions from user to world 1
                    $stmt2->execute([":src" => $world_id, ":dest" => $account_id, ":balance_change" => $amount, ":transaction_type" => 'withdraw', ":memo" => $memo, ":expected_total" => $world_balance+$amount]);
                    $stmt2->execute([":src" => $account_id, ":dest" => $world_id, ":balance_change" => -$amount, ":transaction_type" => "withdraw", ":memo" => $memo, ":expected_total" => $balance-$amount]);
                    //update world and user account with new balance
                    $stmt2 = $db->prepare("UPDATE Accounts SET balance=:new_balance WHERE id=:id");
                    $stmt2->execute([":new_balance" => $world_balance+$amount, ":id" => $world_id]);
                    $stmt2->execute([":new_balance" => $balance-$amount, ":id" => $account_id]);
                    
                } catch (Exception $e)
                {
                    $code = se($e->errorInfo, 0, "00000", false);
                    if ($code != "23000")
                        throw $e;
                }
                checkCloseAccount($account_id);
                $_SESSION["success"] = "successful withdraw";
                header("Location: withdraw.php");
                $selected_account = "";
                $amount = "";
                $memo = "";
            }
        }
    }
}
?>
<form method="POST" id="form" onsubmit="return validate(this);">
    <label for="select_account" class="form-label">Select account</label>
    <select class="form-select w-25" id="select_account" name="select_account" required>
        <option hidden value="">Choose account</option>
        <?php
            foreach ($accounts as $account)
            {
                $frozen = $account->frozen;
                $account_number = $account->account_number; 
                $account_type = $account->account_type;
                $balance = $account->balance; 
                if ($frozen == FALSE) { ?>
                    <option <?php if($selected_account == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | ".$balance;?></option>
                <?php }
                if ($frozen == TRUE) { ?>
                    <option disabled <?php if($selected_account == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | ".$balance;?></option>
                <?php }
            }
        ?>
    </select><br>
    <label for="amount" class="form-label">Enter amount</label>
    <div class="input-group mb-3 w-50">
        <span class="input-group-text">$</span>
        <input type="number" class="form-control" name="amount" id="amount" value="<?php se($amount); ?>" step="0.01" required aria-label="Amount">
    </div>
    <label for="memo" class="form-label">Memo</label>
    <div class="mb-3 w-50">
        <textarea class="form-control" name="memo" id="memo"><?php echo $memo; ?></textarea>
    </div><br>
    <div>
        <button type="submit" name="withdraw" value="withdraw" class="btn btn-primary">Withdraw</button>
    </div>
</form>
<?php
require(__DIR__ . "/../../partials/footer.php");
?>
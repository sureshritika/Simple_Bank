<?php

die(header("Location: login.php"));
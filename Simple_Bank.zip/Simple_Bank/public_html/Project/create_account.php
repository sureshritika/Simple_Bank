<?php
require_once(__DIR__ . "/../../partials/nav.php");
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<?php
$account_type = se($_POST, "account_type", "", false);
$amount = se($_POST, "amount", "", false);
//flash("$account_type|$amount");
$user_id = get_user_id();
$email = get_user_email();
$username = get_username();
$first = get_first();
$last = get_last();
if (is_logged_in(true))
{
    $id = get_user_id();
    $db = getDB();
    //get accounts info
    $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created from Accounts where user_id = :id");
    try
    {
        $r = $stmt->execute([":id" => $id]);
        if ($r)
            $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    catch (Exception $e)
    {
        flash("<pre>" . var_export($e, true) . "</pre>");
    }
    if (isset($_POST["save"])) {
        $hasError = false;
        //check amount for min
        if ($amount < 5.00)
        {
            flash("Minimum $5.00 deposit required for $account_type account.", "danger");
            $hasError = true;
        }
        if (!$hasError)
        {
            //generate random account number
            $account_number = get_random_str((12));
            $db = getDB();
            //create account 1
            $stmt = $db->prepare("INSERT INTO Accounts (account_number, user_id, balance, account_type, apy) VALUES (:account_number, :user_id, :balance, :account_type, :apy)");
            try
            {  
                //set apy (saving:0.05%)
                $apy = 0;
                if ($account_type == "savings")
                    $apy = 0.05;
                $interest = $amount*($apy/100);
                $amount = $amount + $interest;
                //get world
                $stmt2 = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created from Accounts WHERE account_type='world'");
                $stmt2->execute();
                $world = $stmt2->fetch(PDO::FETCH_OBJ);
                $world_id = $world->id;
                $world_account_number = $world->account_number;
                $world_user_id = $world->user_id;
                $world_balance = $world->balance;
                //update world balance
                $stmt3 = $db->prepare("UPDATE Accounts SET balance=$world_balance-$amount WHERE account_type='world'");
                $stmt3->execute();
                //create account 2
                $stmt->execute([":account_number" => $account_number, ":user_id" => $user_id, ":balance" => $amount, ":account_type" => $account_type, ":apy" => $apy]);
                //create new account deposit in transactions for user and world 
                $stmt4 = $db->prepare("INSERT INTO Transactions (src, dest, balance_change, transaction_type, memo, expected_total) VALUES (:src, :dest, :balance_change, :transaction_type, :memo, :expected_total)");
                try
                {
                    $account_id = $db->lastInsertId();
                    $stmt4->execute([":src" => $world_id, ":dest" => $account_id, ":balance_change" => -$amount, ":transaction_type" => 'deposit', ":memo" => 'account opened', ":expected_total" => $world_balance-$amount]);
                    $stmt4->execute([":src" => $account_id, ":dest" => $world_id, ":balance_change" => $amount, ":transaction_type" => "deposit", ":memo" => "account opened", ":expected_total" => $amount]);
                } catch (Exception $e)
                {
                    $code = se($e->errorInfo, 0, "00000", false);
                    if ($code != "23000")
                        throw $e;
                }
                
                flash("successfully created account", "success");
            } catch (Exception $e)
            {
                $code = se($e->errorInfo, 0, "00000", false);
                if ($code != "23000")
                    throw $e;
            }  
            die(header("Location: my_accounts.php"));
        }
        
    }
}
?>
<div class="container-fluid">
    <h1>Create Account</h1>
    <form method="POST" onsubmit="return validate(this);">
        <label class="form-label" for="account_type">Select account type</label>    
        <div>   
            <input type="radio" id="checking" name="account_type" value="checking" <?php if (isset($_POST["account_type"]) && $_POST["account_type"]==='checking') {echo 'checked="checked"';} ?> required>
            <label style="display:inline-block" for="checking">Checking</label><br>
            <input type="radio" id="savings" name="account_type" value="savings" <?php if (isset($_POST["account_type"]) && $_POST["account_type"]==='savings') {echo 'checked="checked"';} ?>>
            <label style="display:inline-block" for="savings">Savings</label><br>
        </div><br>
        <div>
            <label id="amount_label" class="form-label">Enter deposit</label>
            <small id="amount_small" class="form-text text-muted">Minimum $5.00 deposit required for <?php echo $account_type; ?> account.</small>
            <div>
            <div class="input-group w-50">
                <span class="input-group-text">$</span>
                <input type="number" class="form-control" name="amount" id="amount" value="<?php se($amount); ?>" min="0" step="0.01" required aria-label="Amount"> 
            </div>
            </div>
        </div><br>
        <input type="submit" class="mt-3 btn btn-primary" value="Create Account" name="save" />
    </form>
</div>
<script>
function validate(form) {
    return true;
}
</script>
<?php
require_once(__DIR__ . "/../../partials/footer.php");
?>
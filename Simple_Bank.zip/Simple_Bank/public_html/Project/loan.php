<?php
require_once(__DIR__ . "/../../partials/nav.php");
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<?php
$account_type = "loan";
//load apy = 0.10%
$apy = se($_POST, "apy", "", false);
if (empty($apy))
    $apy = 0.1;
$amount = (float)se($_POST, "amount", "", false);
$interest = $amount*($apy/100);
$balance = $amount + $interest;
$deposit = se($_POST, "deposit", "", false);
if (is_logged_in(true))
{
    $id = get_user_id();
    $db = getDB();
    //get accounts info
    $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created, apy, active, frozen from Accounts where user_id = :id AND active = TRUE AND account_type != 'loan'");
    try
    {
        $r = $stmt->execute([":id" => $id]);
        if ($r)
            $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    catch (Exception $e)
    {
        flash("<pre>" . var_export($e, true) . "</pre>");
    }
    if (isset($_POST["save"])) {
        $hasError = false;
        //check amount for min
        if ($amount < 500.00)
        {
            flash("Minimum $500.00 deposit required for loan.", "danger");
            $hasError = true;
        }
        if (!$hasError)
        {
            //generate random account number
            $account_number = get_random_str((12));
            $db = getDB();
            //create account 1
            $stmt = $db->prepare("INSERT INTO Accounts (account_number, user_id, balance, account_type, apy) VALUES (:account_number, :user_id, :balance, :account_type, :apy)");
            try
            {  
                
                //get row index of deposit selected dropdown
                $row_index = 0;
                for ($a = 0 ; $a < sizeof($accounts) ; $a ++)
                {
                    if ($accounts[$a]->account_number == $deposit)
                        $row_index = $a;
                }
                $deposit_account_id = $accounts[$row_index]->id;
                $deposit_balance = $accounts[$row_index]->balance;
                //update deposit balance
                $stmt3 = $db->prepare("UPDATE Accounts SET balance=$deposit_balance-$balance WHERE user_id=$deposit_account_id");
                $stmt3->execute();
                //create account 2
                $stmt->execute([":account_number" => $account_number, ":user_id" => $id, ":balance" => $balance, ":account_type" => $account_type, ":apy" => $apy]);
                //create new account deposit in transactions for loan and deposit 
                $stmt4 = $db->prepare("INSERT INTO Transactions (src, dest, balance_change, transaction_type, memo, expected_total) VALUES (:src, :dest, :balance_change, :transaction_type, :memo, :expected_total)");
                try
                {
                    $account_id = $db->lastInsertId();
                    $stmt4->execute([":src" => $deposit_account_id, ":dest" => $account_id, ":balance_change" => -$balance, ":transaction_type" => 'deposit', ":memo" => 'took out loan', ":expected_total" => $deposit_balance-$balance]);
                    $stmt4->execute([":src" => $account_id, ":dest" => $deposit_account_id, ":balance_change" => $balance, ":transaction_type" => "deposit", ":memo" => "took out loan", ":expected_total" => $balance]);
                } catch (Exception $e)
                {
                    $code = se($e->errorInfo, 0, "00000", false);
                    if ($code != "23000")
                        throw $e;
                }
                
                flash("successfully created account", "success");
            } catch (Exception $e)
            {
                $code = se($e->errorInfo, 0, "00000", false);
                if ($code != "23000")
                    throw $e;
            }  
            die(header("Location: my_accounts.php"));
        }
    }
}
?>
<div class="container-fluid">
    <h1>Loan</h1>
    <form id="loan" method="POST" onsubmit="return validate(this);">
        <div>
            <label id="amount_label" class="form-label">Enter loan principal</label>
            <small id="amount_small" class="form-text text-muted">Minimum $500.00 required for <?php echo $account_type; ?>.</small>
                <div class="input-group w-50">
                    <span class="input-group-text">$</span>
                    <input type="number" class="form-control" name="amount" id="amount" value="<?php se($amount); ?>" min="0" step="0.01" required aria-label="Amount"> 
                </div>
        </div><br>
        <label for="deposit" class="form-label">Deposit into</label>
        <select class="form-select w-50" id="deposit" name="deposit" required>
            <option hidden value="">Choose account</option>
            <?php
                foreach ($accounts as $account)
                {
                    $frozen = $account -> frozen;
                    $account_number = $account->account_number; 
                    $account_type = $account->account_type;
                    $balance = $account->balance;
                    if ($frozen == FALSE) { ?>
                        <option <?php if($deposit == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | $".$balance;?></option>
                    <?php }
                    if ($frozen == TRUE) { ?>
                        <option disabled <?php if($deposit == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | $".$balance;?></option>
                    <?php }
                }
            ?>
        </select><br>
        <div class="form-group">
            <label for="apy">APY</label>
            <div class="input-group">
                <input type="number" class="form-control" id="apy" min="0.10" name="apy" value="<?php se($apy); ?>" step="0.01" placeholder="0.10" aria-describedby="depositHelp"/>
                <div class="input-group-prepend">
                    <span class="input-group-text">%</span>
                </div>    
            </div>
            <small id="apyHelp" class="form-text text-muted">Minimum 0.1% APY.</small>
        </div><br>
        <input type="submit" class="mt-3 btn btn-primary" value="Create Account" name="save" />
    </form>
</div>
<script>
function validate(form) {
    return true;
}
</script>
<?php
require_once(__DIR__ . "/../../partials/footer.php");
?>
<?php
require(__DIR__ . "/../../partials/nav.php");
?>
<h1>My Accounts</h1>
<?php
if (is_logged_in(true))
{
    if (has_account(true))
    {
        $id = get_user_id();
        $db = getDB();
        //pagination
        $page_limit = 5;
        $page_count = ceil(get_accounts_count($id)/$page_limit);
        if (!isset($_GET['page_no']))
            $page_no = 1;
        else
            $page_no = (int)$_GET['page_no'];
        $page_start = ($page_no-1)*$page_limit;
        //print account with page limit
        $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created, apy, active, frozen from Accounts where user_id = :id AND active = TRUE LIMIT $page_start, $page_limit");
        try
        {
            $r = $stmt->execute([":id" => $id]);
            if ($r)
            {
                $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
                //echo '<pre>'; print_r($accounts); echo '</pre>';
                $no = $page_no > 1 ? $page_start+1 : 1;                
            } 
        }
        catch (Exception $e)
        {
            flash("<pre>" . var_export($e, true) . "</pre>");
        }
    }
}
?>
<table class="table" id="accounts">
    <thead>
        <tr>
            <th>Account number</th>
            <th>Account type</th>
            <th>Balance</th>
        </tr>
    </thead>
    <tbody>
        <?php
            foreach ($accounts as $account)
            {
                //click row to take to transaction history by sending row index
                if ($account->frozen == TRUE)
                    echo "<tr disabled>";
                else
                    echo "<tr id='account' onclick='redirect(this)' data-href='transaction_history.php'>";
                    echo "<td>$account->account_number</td>";
                    echo "<td>$account->account_type<br>";
                        if($account->account_type=="checking")
                            echo "APY:--</td>";
                        else
                            echo "APY:".(float)$account->apy."%</td>";
                    echo "<td>$account->balance</td>";
                echo "</tr>"; 
            }
            $no++;
        ?> 
    </tbody> 
</table>
<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item <?= $page_no <= 1 ? 'disabled': ''; ?>">
      <a class="page-link" href="<?= '?page_no='.$page_no-1; ?>" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <?php for($p=1; $p<=$page_count; $p++){?>
        <li class="<?= $page_no == $p ? 'active' : ''; ?>"><a class="page-link" href="<?= '?page_no='.$p; ?>"><?=$p?></a></li>
    <?php }?>
    <li class="page-item <?= $page_no >= $page_count ? 'disabled': ''; ?>">
      <a class="page-link" href="<?= '?page_no='.$page_no+1; ?>" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script>
    function redirect(account)
    {
        //document.location.href="transaction_history.php";
        //sessionStorage.setItem("row_index",account.rowIndex-1);
        //alert(account.dataset.href + "?row_index=" + (account.rowIndex-1));
        var page_no = <?php echo $page_no;?>;
        var page_limit = <?php echo $page_limit;?>;
        var row_index = account.rowIndex-1;
        if (page_no>1)
            row_index = (page_limit*(page_no-1))+row_index;
        window.location = account.dataset.href + "?row_index=" + row_index;
    }
</script>
<?php
require(__DIR__ . "/../../partials/footer.php");
?>
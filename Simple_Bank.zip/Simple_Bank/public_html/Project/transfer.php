<?php
require(__DIR__ . "/../../partials/nav.php");
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<h1>Transfer</h1>
<script>
    function validate(form)
    {
        return true;
    }
</script>
<?php
$src = se($_POST, "src", "", false);
$dest = se($_POST, "dest", "", false);
$amount = se($_POST, "amount", "", false);
$dest_last = se($_POST, "dest_last", "", false);
$dest_account = se($_POST, "dest_account", "", false);
$memo = se($_POST, "memo", "", false);
/*
echo "src: $src<br>";
echo "dest: $dest<br>";
echo "amount: $amount<br>";
echo "memo: $memo<br>";
echo "dest_last: $dest_last<br>";
echo "dest_account: $dest_account<br>";
*/
if (is_logged_in(true)) {
    if (has_account(true))
    {
        if (isset($_SESSION["success"]))
        {
            flash("successful transfer", "success");
            unset($_SESSION["success"]);
        }
        $id = get_user_id();
        $db = getDB();
        //get accounts info
        $stmt = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created, apy, active, frozen from Accounts where user_id = :id AND active = TRUE");
        try
        {
            $r = $stmt->execute([":id" => $id]);
            if ($r)
                $accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        catch (Exception $e)
        {
            flash("<pre>" . var_export($e, true) . "</pre>");
        }
        //transfer button clicked
        if(isset($_POST["transfer"]))
        {
            $hasError = false;
            //check zero transfer
            if ($amount == 0)
            {
                flash("Zero transfer not allowed", "danger");
                $hasError = true;
            }
            //check minus transfer
            if ($amount < 0)
            {
                flash("Transfer amount value must be positive number", "danger");
                $hasError = true;
            }
            //check filters
            if ((!empty($dest) && (!empty($dest_last) || !empty($dest_account))) || (empty($dest) && empty($dest_last) && empty($dest_account)))
            {
                flash("Choose one. Transfer between own accounts or transfer to another users account", "danger");
                $hasError = true;
            }
            else
            {
                if (empty($dest))
                {
                    if (empty($dest_last))
                    {
                        flash("Enter destination user's last name", "danger");
                        $hasError = true;
                    }
                    if (empty($dest_account))
                    {
                        flash("Enter destination user's account number", "danger");
                        $hasError = true;
                    }
                    if (!empty($dest_account) && strlen($dest_account)<4)
                    {
                        flash("Enter last 4 digits of destination user's account number", "danger");
                        $hasError = true;
                    }
                }
            }
            //get src info
            $src_index = 0;
            for ($a = 0 ; $a < sizeof($accounts) ; $a ++)
            {
                if ($accounts[$a]->account_number == $src)
                    $src_index = $a;
            }
            $src_id = $accounts[$src_index]->id;
            $src_account = $accounts[$src_index]->account_number;
            $src_balance = $accounts[$src_index]->balance;
            //get dest info
            $type = "";
            //same user
            if (!empty($dest) && (empty($dest_last) && empty($dest_account)))
            {
                $dest_index = 0;
                for ($a = 0 ; $a < sizeof($accounts) ; $a ++)
                {
                    if ($accounts[$a]->account_number == $dest)
                        $dest_index = $a;
                }
                $dest_id = $accounts[$dest_index]->id;
                $dest_balance = $accounts[$dest_index]->balance;
                $dest_account_type = $accounts[$dest_index]->account_type;
                $type = "transfer";
            }
            //different user
            else if (empty($dest) && (!empty($dest_last) && !empty($dest_account)))
            {
                //check if dest account number matches
                $stmt2 = $db->prepare("SELECT id, account_number, user_id, balance, account_type, created, apy, active from Accounts");
                try
                {
                    $r2 = $stmt2->execute();
                    if ($r2)
                    {
                        $accounts2 = $stmt2->fetchAll(PDO::FETCH_OBJ);
                        $dest_index = 0;
                        for ($a = 0 ; $a < sizeof($accounts2) ; $a ++)
                        {
                            $stmt3 = $db->prepare("SELECT id, email, username, password, first, last from Users where id = :id");
                            try
                            {
                                if (substr($accounts2[$a]->account_number, -4) == $dest_account)
                                {
                                    $dest_index = $a;
                                    //check if dest last name matches
                                    $r = $stmt3->execute([":id" => $accounts2[$dest_index]->user_id]);
                                    if ($r)
                                    {
                                        $user = $stmt3->fetch(PDO::FETCH_OBJ);
                                        //error if dest last name does not match last name associated with account number
                                        if (strtolower($user->last) != strtolower($dest_last))
                                        {
                                            flash("Destination user last name does not match account number", "danger");
                                            $hasError = true;
                                        }
                                    }
                                }   
                            }
                            catch (Exception $e)
                            {
                                flash("<pre>" . var_export($e, true) . "</pre>");
                            }
                        }
                        //error if dest account number does not exist
                        if ($dest_index == 0)
                        {
                            flash("Destination user account does not exist","danger");
                            $hasError = true;
                        }
                        else if ($accounts2[$dest_index]->active == FALSE)
                        {
                            flash("This is closed account, cannot transfer","danger");
                            $hasError = true;
                        }
                        else
                        {
                            $dest_id = $accounts2[$dest_index]->id;
                            $dest_balance = $accounts2[$dest_index]->balance;
                            $type = "ext-transfer";
                        } 
                    }
                }
                catch (Exception $e)
                {
                    flash("<pre>" . var_export($e, true) . "</pre>");
                }
            }
            //check if transfer amount is less than account balance
            if ($amount > $src_balance)
            {
                flash("Insufficient funds", "danger");
                $hasError = true;
            }
            //continue if no errors
            if (!$hasError)
            {
                
                //insert transfer info into transactions from src to dest
                $stmt2 = $db->prepare("INSERT INTO Transactions (src, dest, balance_change, transaction_type, memo, expected_total) VALUES (:src, :dest, :balance_change, :transaction_type, :memo, :expected_total)");
                try
                {
                    //update src and dest account with new balance
                    $stmt4 = $db->prepare("UPDATE Accounts SET balance=:new_balance WHERE id=:id");
                    //src
                    $stmt2->execute([":src" => $src_id, ":dest" => $dest_id, ":balance_change" => -$amount, ":transaction_type" => $type, ":memo" => $memo, ":expected_total" => $src_balance-$amount]);
                    $stmt4->execute([":new_balance" => $src_balance-$amount, ":id" => $src_id]);
                    //if loan, balance=balance-transfer
                    if ($dest_account_type == "loan")
                        $amount = -$amount;
                    //dest
                    $stmt2->execute([":src" => $dest_id, ":dest" => $src_id, ":balance_change" => $amount, ":transaction_type" => $type, ":memo" => $memo, ":expected_total" => $dest_balance+$amount]);
                    $stmt4->execute([":new_balance" => $dest_balance+$amount, ":id" => $dest_id]);
                    
                    //change apy with new balance
                    if ($dest_account_type == "loan")
                    {
                        $stmt6 = $db->prepare("SELECT balance, apy from Accounts where id = $dest_id");
                        $stmt6->execute();
                        $new_dest_balance = $stmt6->fetch(PDO::FETCH_OBJ)->balance;
                        $stmt6->execute();
                        $dest_apy = $stmt6->fetch(PDO::FETCH_OBJ)->apy;
                        //calc new interest
                        $interest = $new_dest_balance*($dest_apy/100);
                        $balance = (float)$new_dest_balance + (float)$interest;
                        //update balance+interest
                        $stmt5 = $db->prepare("UPDATE Accounts SET balance = $balance WHERE id = $dest_id");
                        $stmt5->execute();
                    }
                    
                } catch (Exception $e)
                {
                    $code = se($e->errorInfo, 0, "00000", false);
                    if ($code != "23000")
                        throw $e;
                }
                
                checkCloseAccount($src_id);
                checkCloseAccount($dest_id);
                $_SESSION["success"] = "successful transfer";
                header("Location: transfer.php");
                $src = "";
                $dest = "";
                $amount = "";
                $memo = "";
                $dest_last = "";
                $dest_account = "";
            }
        }
    }
}
?>
<form method="POST" id="form" onsubmit="return validate(this);">
    <label for="src" class="form-label">From</label>
    <select class="form-select w-25" id="src" name="src" required>
        <option hidden value="">Choose src account</option>
        <?php
            foreach ($accounts as $account)
            {
                $frozen = $account->frozen;
                $account_number = $account->account_number; 
                $account_type = $account->account_type;
                $balance = $account->balance;
                if ($account_type != "loan" && $frozen == FALSE){ ?>
                    <option <?php if($src == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | ".$balance;?></option>
                <?php }
                if ($account_type != "loan" && $frozen == TRUE){ ?>
                    <option disabled <?php if($src == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | ".$balance;?></option>
                <?php }
            }
        ?>
    </select><br>
    <label for="dest" class="form-label">To</label>
    <div id="to">
        <div id="form-content">
            <select class="form-select" id="dest" name="dest">
                <option value="">Choose dest account</option>
                <?php
                    foreach ($accounts as $account)
                    {
                        $frozen = $account->frozen;
                        $account_number = $account->account_number; 
                        $account_type = $account->account_type;
                        $balance = $account->balance;
                        if ($frozen == FALSE){ ?>
                            <option <?php if($src == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | ".$balance;?></option>
                        <?php }
                        if ($frozen == TRUE){ ?>
                            <option disabled <?php if($src == $account_number) echo 'selected="selected"'; ?> value="<?php echo $account_number; ?>"><?php echo $account_number." | ".$account_type." | ".$balance;?></option>
                        <?php }
                    }
                ?>
            </select>
        </div>
        <div id="form-content" class="spacer"></div>
        <label id="form-content">OR</label>
        <div id="form-content" class="spacer"></div>
        <div id="form-content">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" name="dest_last" placeholder="Dest user lastname" value="<?php se($dest_last); ?>">
                <label for="floatingInput">Dest user lastname</label>
            </div>
            <div class="form-floating">
                <input type="text" class="form-control" name="dest_account" placeholder="Dest user account no" maxlength="4" value="<?php se($dest_account) ?>">
                <label for="floatingPassword">Dest user account no</label>
                <small id="dest_account help" class="form-text text-muted">Enter last 4 digits of the destination user's account number</small>
            </div>
        </div>
    </div><br>
    <label for="amount" class="form-label">Enter amount</label>
    <div class="input-group mb-3 w-50">
        <span class="input-group-text">$</span>
        <input type="number" class="form-control" name="amount" id="amount" value="<?php se($amount); ?>" step="0.01" required aria-label="Amount">
    </div><br>
    <label for="memo" class="form-label">Memo</label>
    <div class="mb-3 w-50">
        <textarea class="form-control" name="memo" id="memo"><?php echo $memo; ?></textarea>
    </div><br>
    <div>
        <button type="submit" name="transfer" value="transfer" class="btn btn-primary">Transfer</button>
    </div>
</form>
<?php
require(__DIR__ . "/../../partials/footer.php");
?>
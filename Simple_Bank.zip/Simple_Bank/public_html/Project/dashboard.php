<?php
require(__DIR__ . "/../../partials/nav.php");
?>
<h1>Dashboard</h1>
<?php
if (is_logged_in(true)) {
    echo "Welcome to your dashboard, " . get_first() . " " . get_last();
    $user_id = get_user_id();
    $db = getDB();
    $stmt = $db->prepare("SELECT Users.first, Users.last, Accounts.account_number FROM Users INNER JOIN Accounts ON Users.id=Accounts.user_id WHERE Accounts.account_type != 'world' AND account_type != 'system' AND Users.first='tanika'");
    $stmt->execute();
    $users_accounts = $stmt->fetchAll(PDO::FETCH_OBJ);
    //echo '<pre>'; print_r($users_accounts); echo '</pre>';
}
?>
<br><br>
<div>
    <h5><a href="create_account.php">Create account</a></h5>
    <h5><a href="my_accounts.php">My accounts</a></h5>
    <h5><a href="deposit.php">Deposit</a></h5>
    <h5><a href="withdraw.php">Withdraw</a></h5>
    <h5><a href="transfer.php">Transfer</a></h5>
    <h5><a href="loan.php">Loan</a></h5>
    <h5><a href="profile.php">Profile</a></h5>
    <?php if (has_role("Admin")) : ?>
        <div class="btn-group dropend">
            <h5 class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <a href="">Admin Roles</a>
            </h5>
            <ul class="dropdown-menu">
                <h5><a class="dropdown-item" href="<?php echo get_url('admin/user_management.php'); ?>">User Management</a></h5>
                <h5><a class="dropdown-item" href="<?php echo get_url('admin/account_management.php'); ?>">Account Management</a></h5>
                <h5><a class="dropdown-item" href="<?php echo get_url('admin/admin_open.php'); ?>">Admin Open Account</a></h5>
                <h5><a class="dropdown-item" href="<?php echo get_url('admin/create_role.php'); ?>">Create</a></h5>
                <h5><a class="dropdown-item" href="<?php echo get_url('admin/list_roles.php'); ?>">List</a></h5>
                <h5><a class="dropdown-item" href="<?php echo get_url('admin/assign_roles.php'); ?>">Assign</a></h5>
            </ul>
        </div>
        </div>
    <?php endif; ?>
</div>


<?php
require(__DIR__ . "/../../partials/footer.php");
?>